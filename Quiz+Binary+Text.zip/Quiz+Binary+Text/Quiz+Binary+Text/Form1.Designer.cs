﻿namespace Quiz_Binary_Text
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.label_Plus = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lbl_Equal = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnShowGood = new System.Windows.Forms.Button();
            this.listWindow = new System.Windows.Forms.ListBox();
            this.btnShowBad = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblNum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNum1.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblNum1.Font = new System.Drawing.Font("Impact", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(13, 26);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(143, 80);
            this.lblNum1.TabIndex = 0;
            // 
            // label_Plus
            // 
            this.label_Plus.AutoSize = true;
            this.label_Plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_Plus.Location = new System.Drawing.Point(204, 39);
            this.label_Plus.Name = "label_Plus";
            this.label_Plus.Size = new System.Drawing.Size(44, 46);
            this.label_Plus.TabIndex = 1;
            this.label_Plus.Text = "+";
            // 
            // lblNum2
            // 
            this.lblNum2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblNum2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNum2.Font = new System.Drawing.Font("Impact", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.Location = new System.Drawing.Point(300, 23);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(133, 83);
            this.lblNum2.TabIndex = 1;
            // 
            // lbl_Equal
            // 
            this.lbl_Equal.AutoSize = true;
            this.lbl_Equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_Equal.Location = new System.Drawing.Point(481, 39);
            this.lbl_Equal.Name = "lbl_Equal";
            this.lbl_Equal.Size = new System.Drawing.Size(44, 46);
            this.lbl_Equal.TabIndex = 3;
            this.lbl_Equal.Text = "=";
            // 
            // txtResult
            // 
            this.txtResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtResult.Location = new System.Drawing.Point(570, 39);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(194, 56);
            this.txtResult.TabIndex = 4;
            this.txtResult.TextChanged += new System.EventHandler(this.txtResult_TextChanged);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Yellow;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnStart.ForeColor = System.Drawing.Color.Red;
            this.btnStart.Location = new System.Drawing.Point(2, 426);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(195, 109);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.Color.Fuchsia;
            this.btnCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnCheck.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCheck.Location = new System.Drawing.Point(257, 426);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(225, 109);
            this.btnCheck.TabIndex = 6;
            this.btnCheck.Text = "CHECK";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnShowGood
            // 
            this.btnShowGood.BackColor = System.Drawing.Color.Red;
            this.btnShowGood.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnShowGood.ForeColor = System.Drawing.Color.Yellow;
            this.btnShowGood.Location = new System.Drawing.Point(555, 426);
            this.btnShowGood.Name = "btnShowGood";
            this.btnShowGood.Size = new System.Drawing.Size(220, 109);
            this.btnShowGood.TabIndex = 8;
            this.btnShowGood.Text = "SHOW GOOD";
            this.btnShowGood.UseVisualStyleBackColor = false;
            this.btnShowGood.Click += new System.EventHandler(this.btnShowGood_Click);
            // 
            // listWindow
            // 
            this.listWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.listWindow.FormattingEnabled = true;
            this.listWindow.ItemHeight = 29;
            this.listWindow.Location = new System.Drawing.Point(793, 39);
            this.listWindow.Name = "listWindow";
            this.listWindow.Size = new System.Drawing.Size(314, 352);
            this.listWindow.TabIndex = 9;
            this.listWindow.SelectedIndexChanged += new System.EventHandler(this.listWindow_SelectedIndexChanged);
            // 
            // btnShowBad
            // 
            this.btnShowBad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnShowBad.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnShowBad.ForeColor = System.Drawing.Color.Lime;
            this.btnShowBad.Location = new System.Drawing.Point(850, 426);
            this.btnShowBad.Name = "btnShowBad";
            this.btnShowBad.Size = new System.Drawing.Size(208, 109);
            this.btnShowBad.TabIndex = 10;
            this.btnShowBad.Text = "SHOW BAD";
            this.btnShowBad.UseVisualStyleBackColor = false;
            this.btnShowBad.Click += new System.EventHandler(this.btnShowBad_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(1136, 584);
            this.Controls.Add(this.btnShowBad);
            this.Controls.Add(this.listWindow);
            this.Controls.Add(this.btnShowGood);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.lbl_Equal);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.label_Plus);
            this.Controls.Add(this.lblNum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label label_Plus;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lbl_Equal;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnShowGood;
        private System.Windows.Forms.ListBox listWindow;
        private System.Windows.Forms.Button btnShowBad;
    }
}


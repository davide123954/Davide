﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Quiz_Binary_Text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int num1, num2;
      

        private void btnCheck_Click(object sender, EventArgs e)
        {
            try
            {
                int result;
                result = int.Parse(txtResult.Text);
                txtResult.Enabled = false;

                if (num1 + num2 == result)
                {
                    int n1, n2, res;
                    n1 = int.Parse(lblNum1.Text);
                    n2 = int.Parse(lblNum2.Text);
                    res = int.Parse(txtResult.Text);

                    FileStream g = new FileStream("good.txt", FileMode.Append);//create file or append
                    StreamWriter m = new StreamWriter(g);
                    m.WriteLine(n1);
                    m.WriteLine(n2);
                    m.WriteLine(res);
                    m.Close();
                    g.Close();
                    MessageBox.Show("SAVED TRUE ANSWER");
                    lblNum1.Text = "";
                    lblNum2.Text = "";
                    txtResult.Text = "";
                }
                else
                {
                    int n1, n2, res;
                    n1 = int.Parse(lblNum1.Text);
                    n2 = int.Parse(lblNum2.Text);
                    res = int.Parse(txtResult.Text);

                    FileStream g = new FileStream("bad.txt", FileMode.Append);//create file or append
                    StreamWriter m = new StreamWriter(g);
                    m.WriteLine(n1);
                    m.WriteLine(n2);
                    m.WriteLine(res);
                    m.Close();
                    g.Close();
                    MessageBox.Show("SAVED NOT ANSWER");
                    lblNum1.Text = "";
                    lblNum2.Text = "";
                    txtResult.Text = "";
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "targil", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtResult.Text = "";
            }
        }

        private void btnShowGood_Click(object sender, EventArgs e)
        {
            
                listWindow.Items.Clear();
                StreamReader sr = new StreamReader("good.txt"); //open file
                string s = "", str;
                while ((s = sr.ReadLine()) != null) //end file text
                {
                    str = s + " +" + sr.ReadLine() + "= "+ sr.ReadLine();
                    listWindow.Items.Add(str);
                }
                sr.Close();
        }

        private void listWindow_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnShowBad_Click(object sender, EventArgs e)
        {
            listWindow.Items.Clear();
            StreamReader sr = new StreamReader("bad.txt"); //open file
            string s = "", str;
            while ((s = sr.ReadLine()) != null) //end file text
            {
                str = s + " +" + sr.ReadLine() + "= " + sr.ReadLine();
                listWindow.Items.Add(str);
            }
            sr.Close();
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            num1 = rnd.Next(10);
            num2 = rnd.Next(11);
            lblNum1.Text = num1.ToString();
            lblNum2.Text = num2.ToString();
            txtResult.Enabled = true;
            txtResult.Text = "";
            //lblStart.Text = "PLUS\n   +";
        }
    }
}




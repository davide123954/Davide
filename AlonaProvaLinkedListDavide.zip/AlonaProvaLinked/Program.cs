using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlonaProvaLinked
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice, x;
            string names = "", bari = "";
            Linked list = new Linked();
            Console.WriteLine("WELCOME TO THE SUPERPHARM :)");
            list.CreateList();
            while (true)
            {
                Console.WriteLine("1.DETAILS OF THE TURN/LIST: ");
                Console.WriteLine("2.COUNT OF NODES ARE: ");
                Console.WriteLine("3.SEARCH ONE ELEMENT BY NAME IN THE LIST: ");
                Console.WriteLine("4.INSERT AT BEGGINER OF THE LIST(ATHALA-ROSH RESHIMA)ONLY IF HIS HEALTHY IS BAD");
                Console.WriteLine("5.INSERT A NAME TO BE THE LAST AT THE LIST(TO THE END OF TURN)");
                Console.WriteLine("6.INSERT A NEW PERSON AFTER SPECIFIC PERSON AT THE TURN BY NAME");
                Console.WriteLine("7.ADD A NEW PERSON IN THE POSITION YOU WANT IT TO BE");
                Console.WriteLine("8.DELETE FIRST PEOPLE FROM THE TURN");
                Console.WriteLine("9.DELETE THE LAST PERSON OF THE TURN ");
                Console.WriteLine("10.DELETE ONE PERSON AT THE TURN BY NAME");
                Console.WriteLine("11.EXIT");
                Console.Write("Enter your choice : "); 
                choice = int.Parse(Console.ReadLine());
                if (choice == 11)
                    break;
                switch (choice)
                {
                    case 1:
                        list.DisplayList();
                        break;
                    case 2:
                        list.CountNodes();
                        break;
                    case 3:
                        Console.Write("ENTER THE NAME YOU WISH TO BE SERCHED IN THE LIST: ");
                        names = Console.ReadLine();
                        list.Search(names);
                        break;
                    case 4:
                        Console.Write("ENTER A NAME TO BE INSERT AT BEGIN(ATHALA)ONLY IF HIS FEELING BAD ('_') : ");
                        names = Console.ReadLine();
                        Console.Write("DO YOU FEEL GOOD TODAY?: ");
                        bari = Console.ReadLine();
                        if(bari=="no"|| bari=="No" || bari=="NO"  || bari=="bad"|| bari== "Bad" || bari== "BAD")
                            list.InsertInBeginning(names, bari);
                        break;
                    case 5:
                        Console.Write("ENTER A NAME TO BE INSERT AT THE END OF THE TURN: ");
                        names = Console.ReadLine();
                        Console.Write("DO YOU FEEL GOOD TODAY?: ");
                        bari = Console.ReadLine();
                        if (bari == "no" || bari == "No" || bari == "NO" || bari == "bad" || bari == "Bad" || bari == "BAD")
                            list.InsertInBeginning(names, bari);
                        else
                            list.InsertAtEnd(names, bari);
                        break;
                    case 6:
                        Console.Write("ENTER A NEW PEOPLE BY NAME  TO BE INSERTED AT THE TURN : ");
                        names = Console.ReadLine();
                        Console.Write("DO YOU FEEL GOOD TODAY?: ");
                        bari = Console.ReadLine();
                        Console.Write("ENTER THE POSITION YOU WANT THE NEW PERSON TO RECEIVE(MUST BE INTIGER,AND BY ORDER OF THE LIST-TURN): ");
                        x = int.Parse(Console.ReadLine());
                        list.InsertAfter(names,bari,x);
                        break;
                    case 7:
                        Console.Write("ENTER A NEW PEOPLE BY NAME TO BE INSERETED AT THE TURN: ");
                        names = Console.ReadLine();
                        Console.Write("DO YOU FEEL GOOD TODAY?: ");
                        bari = Console.ReadLine();
                        Console.Write("ENTER THE POSITION-MIKUM AT WIILL BE THE NEW PEOPLE : ");
                        x = int.Parse(Console.ReadLine());
                        list.InsertAtPosition(names,bari, x);
                        break;
                    case 8:
                        list.DeleteFirstNode();
                        break;
                    case 9:
                        list.DeleteLastNode();
                        break;
                    case 10:
                        Console.Write("ENTER THE NAME OF A PERSON AT TURN YOU WANT TO DELETE : ");
                        names = Console.ReadLine();
                        list.DeleteNode(names);
                        break;
                    default:
                        Console.WriteLine("NOOO!!!!!!!!!!!!WRONG CHOICE!!!!!!");
                        break;
                }
                Console.WriteLine();
            }
            Console.WriteLine("EXIT");
            Console.WriteLine("THANK FOR WATCHING :) ");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlonaProvaLinked
{
    class Node
    {
        public int info;
        public Node link;
        public Node next = null;
        public string names;
        public string bari;

        public Node(string names)
        {
            this.names = names;
        }

        public Node(string names,string bari)
        {
            this.names = names;
            this.bari = bari;
        }
      
        public Node(int i,string names)
        {
            info = i;
            link = null;
            this.names = names;
        }
        //public Node(Node link) { this.link = link; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlonaProvaLinked
{
    class Linked
    {
        Node start = null;
        public Linked() { start = null; }
        public void DisplayList()
        {
            Node p;
            if (start == null)
            {
                Console.WriteLine("LIST IS EMPITY SORRY ... (-_-)...");
                return;
            }
            p = start;
            while (p != null)
            {
                Console.WriteLine("NAMES: " + p.names + " " + "    STATUS HEALTHY: " + p.bari);
                p = p.link;
            }
            Console.WriteLine();
        }
        public void CountNodes()
        {
            int n = 0;
            Node p = start;
            while (p != null)
            {
                n++;
                p = p.link;
            }
            Console.WriteLine("PEOPLES AT LIST/TURN ARE = " + n);
        }
        public bool Search(string names)
        {
            int position = 1;
            Node p = start;
            while (p != null)
            {
                if (p.names == names)
                    break;
                position++;
                p = p.link;
            }
            if (p == null)
            {
                Console.WriteLine(names + " NOT FOUND...");
                return false;
            }
            else
            {
                Console.WriteLine(names + " IS IN POSITION " + position);
                return true;
            }
        }
        public void InsertInBeginning(string names, string bari)
        {
            Node temp = new Node(names, bari);
            temp.link = start;
            start = temp;
        }
        public void InsertAtEnd(string names, string bari)
        {
            Node p;
            Node temp = new Node(names, bari);
            if (start == null)
            {
                start = temp;
                return;
            }
            p = start;
            while (p.link != null)
                p = p.link;
            p.link = temp;
        }
        public void CreateList()
        {
            int i, num;
            string names = "", bari = "";
            Console.Write("ENTER MAXIMUM QUANTITY OF PEOPLES AT TURN : ");
            num = int.Parse(Console.ReadLine());
            if (num == 0)
                return;
            for (i = 1; i <= num; i++)
            {
                Console.Write("ENTER THE NAMES OF PERSON TO BE INSERTED IN THE LIST : ");
                names = Console.ReadLine();
                Console.Write("DO YOU FEEL GOOD TODAY?: ");
                bari = Console.ReadLine();
                InsertAtEnd(names, bari);
            }
        }
        public void InsertAfter(string names, string bari, int x)
        {
            Node p = start;
            while (p != null)
            {
                if (p.info != x)
                    break;
                p = p.link;
            }
            if (p == null)
                Console.WriteLine(x + " INEXISTENT IN THE LIST");
            else
            {
                Node temp = new Node(names, bari);
                temp.link = p.link;
                p.link = temp;

            }
        }
       // public void InsertBefore(string names, string bari, int x)// bdika only with 0 is work
       // {
            //Node temp;
            //if (start == null)
            //{
            //    Console.WriteLine("LIST IS EMPITY(MUST TO CREATE A LIST)");
            //    return;
            //}
            //if (x == start.info)
            //{
            //    temp = new Node(names, bari);
            //    temp.link = start;
            //    start = temp;
            //    return;
            //}
            //Node p = start;
            //while (p.link != null)
            //{
            //    if (p.link.info == x)
            //        break;
            //    p = p.link;
            //}
            //if (p.link == null)
            //    Console.WriteLine(x + " INEXISTENT IN THE LIST");
            //else
            //{
            //    temp = new Node(names, bari);
            //    temp.link = p.link;
            //    p.link = temp;
            //}
       // }
        public void InsertAtPosition(string names,string bari, int k)
        {
            Node temp;
            int i;
            if (k == 1)
            {
                temp = new Node(names,bari);
                temp.link = start;
                start = temp;
                return;
            }
            Node p = start;
            for (i = 1; i < k - 1 && p != null; i++)
                p = p.link;
            if (p == null)
                Console.WriteLine("You can insert only upto " + i + "th position");
            else
            {
                temp = new Node(names,bari);
                temp.link = p.link;
                p.link = temp;
            }
        }
        public void DeleteFirstNode()
        {
            if (start == null)
                return;
            start = start.link;
        }
        public void DeleteLastNode()
        {
            if (start == null)
                return;
            if (start.link == null)
            {
                start = null;
                return;
            }
            Node p = start;
            while (p.link.link != null)
                p = p.link;
            p.link = null;
        }
        public void DeleteNode(string names )
        {
            if (start == null)
            {
                Console.WriteLine("LIST IS EMPITY \n");
                return;
            }
            if (start.names == names)
            {
                start = start.link;
                return;
            }
            Node p = start;
            while (p.link != null)
            {
                if (p.link.names == names)
                    break;
                p = p.link;
            }
            if (p.link == null)
                Console.WriteLine("NAME OF THIS PERSON " + names + " IS NOT IN THE LIST");
            else
                p.link = p.link.link;
        }
    }
}

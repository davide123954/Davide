'davide baruzzo 341232460'
'''
'targhil 1 pi'
def pi(num):
      per,pay =1,0
      for i  in range (num):
            pay+=4/(i*2+1)*per
            per *=-1
      return pay
print("enter your number you will get the pay: ")
print(pi(int(input())))

'targhil 2'
def booleani(num):
      flag=False
      if num%2==0:
            flag=True
      else:
            flag=False
      print("the flag is: ", flag)
def last_digit(num):
      num=num%10
      print("the last digit is: ",num)
def without_last_digit(num):
            num=num//10
            print("without last digit is : ",num)
def multiply(num):
      print("multiply of the number is : ",num*10)
def with_two_parameter(num,num2):
      print("num1 multiply the number2 : ",num*10+num2)
def reverse_num(num):
      reverse = 0
      temp=0
      while(num > 0):     
            temp = num %10
            reverse = (reverse *10) + temp
            num = num //10
      print("\n Reverse of entered number is = %d",reverse)
def zughi(n):
      x=0
      num=0
      while n>0:
            x=n%10
            n=n//10
            if(x%2==0):
                  num+=x
                  num*=10
      num=num//10
      y=0
      while num>0:
            y=y*10+num%10
            num=num//10
      print(y)
num = int(input('enter number : '))
zughi(num)
booleani(num)
last_digit(num)
without_last_digit(num)
multiply(num)
num2=int(input("enter num2 : "))
with_two_parameter(num,num2)
num = int(input("Please Enter any Number and you will get the reverse: "))
reverse_num(num)

'targhil 3 '
def f1(x):
      c=0
      count=0
      temp=x
      while temp >0:
            count=count+temp%10
            temp=temp//10
      print ("the count of your digits is: ",count)
def f2(x):
      c=0
      if x%2 ==0:
            while x>0:
                  if(x%10)%2==0:
                        c=c+x%10
                  x=x//10
            print("the count of pari is : ",c)
      else:
            while x>0:
                  if(x%10)%2==0:
                        
                        c=c+x%10
                  x=x//10
                  
            print("the count dispari is: ",c)
x=int(input('enter number : '))
f1(x)
x=int(input('enter number : '))
f2(x)

'targhil 4'


def f1(x,y):
      maxdigit_x=x%10
      maxdigit2=x=x//10
      c=0
      count=0
      count2=0
      temp=x
      temp2=y
      while x >0:
           x%10
           x=x//10
           count+=1
           if temp == x:
                 break
      while y >0:
            y%10
            y=y//10
            count2+=1
            if temp2 == y:
                  print("ok")
            elif count!= count2:
                  print("the counter are differente so...-1")
            if count == count2:
                  while x>0:
                        x%10
                        x=x//10
                        if maxdigit_x<maxdigit2:
                              maxdigit2=maxdigit_x
                              print("the max of the digit of the x is : ",maxdigit2)
      print("the counter of digits is : ",count)
      print("the counter of second digits is : ",count2)     
x=int(input('enter number : '))
y=int(input('enter number : '))
f1(x,y)

'targhil 5 kartis lucky'
def lucky(num):
      if a+b+c==d+e+f:
            print("you win!!!!!!!!")
            print("the sum of the primary 3 digits are ugual of the last three digits")
      else:
            print("try again")

num=int(input('enter number of 6 digits please : '))
a=num%10
b=num//10%10
c=num//100%10
d=num//1000%10
e=num//10000%10
f=num//100000
lucky(num)

'targhil 6 multifunzioni'
def multifunc(x,y):
      return x*y
def add(x,y):
      return x+y
def sott(x,y):
      return x-y

x=int(input('enter x  number : '))
y=int(input('enter y number : '))
first=multifunc(x,y)
second=add(x,y)
three=sott(x,y)
print('%d%d%d'%(first,second,three))
'''

















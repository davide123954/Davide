﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Stav_cinema
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            try
            {
                string id = txtId.Text;
                string cardNum = txtCard.Text;
                int digits =int.Parse(txtCvv.Text);
                string validity = txtValidity.Text;
                int pay = int.Parse(comboPayments.Text);
                SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");
                SqlCommand mySqlCommand = mySqlConnection.CreateCommand();
                mySqlConnection.Open();
                mySqlCommand.CommandText = "insert into payment values('" + id + "'," + cardNum + ",'" + validity + "'," + digits + "," + pay + "');";
                if (MessageBox.Show("Are you sure to pay?", "Payment", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    MessageBox.Show("The payment was successful.", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mySqlConnection.Close();
                txtId.Text = "";
                txtCard.Text = "";
                txtCvv.Text = "";
                txtValidity.Text = "";
                comboPayments.Text = "";
            }
            catch 
            {
                MessageBox.Show("All fields are required !!", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtId.Text = "";
                txtCard.Text = "";
                txtCvv.Text = "";
                txtValidity.Text = "";
                comboPayments.Text = "";
            }

        }
    }
}

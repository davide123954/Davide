﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Stav_cinema
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            
            SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Login where Username='"+txtUser.Text+"' and Password ='"+ txtPass.Text+"'",mySqlConnection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1") {

                this.Hide();
                MessageBox.Show("How you doing today admin ?","Welcome screen",MessageBoxButtons.OK,MessageBoxIcon.Information);
                Main admin = new Main();
                admin.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password...", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUser.Text = "";
                txtPass.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Login where Username='" + txtUser.Text + "' and Password ='" + txtPass.Text + "'", mySqlConnection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                string str = txtUser.Text;
                MessageBox.Show("Welcome "+str, "Welcome screen",MessageBoxButtons.OK,MessageBoxIcon.Information);
                User user = new User();
                user.ShowDialog();
            }
            else{
                MessageBox.Show("Invalid Username or Password...", "Login screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUser.Text = "";
                txtPass.Text = "";
            }
        }
    }
  
}

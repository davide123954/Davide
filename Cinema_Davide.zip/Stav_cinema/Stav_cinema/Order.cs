﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Stav_cinema
{
    public partial class Order : Form
    {
        public Order()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string seat = comboBox3.Text;
                SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");//kesher to database
                SqlCommand mySqlCommand = mySqlConnection.CreateCommand();
                mySqlConnection.Open();
                mySqlCommand.CommandText = "insert into Seat values('" + seat + "');";
                int n = mySqlCommand.ExecuteNonQuery();
                mySqlConnection.Close();
                if(comboBox3.SelectedIndex != -1)
                {
                    if(MessageBox.Show("Are you sure to order?","Order Movie", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        comboBox3.Items.RemoveAt(comboBox3.SelectedIndex);
                        MessageBox.Show("Order is successfuly.", "Add Movie", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        richTextBox1.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Plese choose a seat");
                    }
                }
                
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Add seats", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = comboBox3.Text;
            richTextBox1.Text = "Hey " + txtName.Text + "\nyour order the movie: " + comboBox4.Text + "\non the date: " + comboBox1.Text + "\nat the time: " + comboBox2.Text + "\nin seat number: " + str;
            txtName.Text = "";
            comboBox4.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            Payment p = new Payment();
            p.ShowDialog();
        }
    }
}

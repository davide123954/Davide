﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Stav_cinema
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btnPicture_Click(object sender, EventArgs e)
        {
            string str;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                str = openFileDialog1.FileName;
                str = str.Substring(str.LastIndexOf("\\")).Remove(0, 1);
                txtPicture.Text = str;
            }
        }

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            try
            {
                string movie_name = txtName.Text;
                string movie_date = txtDate.Text;
                string time = txtTime.Text;
                float price = float.Parse(txtPrice.Text);
                string picture = txtPicture.Text;
                SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");//kesher to database
                SqlCommand mySqlCommand = mySqlConnection.CreateCommand();
                mySqlConnection.Open();
                mySqlCommand.CommandText = "insert into Admin values('" + movie_name + "'," + movie_date + ",'" + time + "'," + price + ",'" + picture + "');";
                int n = mySqlCommand.ExecuteNonQuery();
                MessageBox.Show("Insert " + n.ToString() + "movie successfuly.", "Add Movie", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mySqlConnection.Close();
                txtName.Text = "";
                txtDate.Text = "";
                txtTime.Text = "";
                txtPrice.Text = "";
                txtPicture.Text = "";
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Add Movie", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e){
            Close();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                string movie_name = txtName.Text;
                SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");//kesher to database
                SqlCommand mySqlCommand = mySqlConnection.CreateCommand();
                mySqlConnection.Open();
                mySqlCommand.CommandText = "delete from Admin where movie_name='" + movie_name + "'"; 
                int n = mySqlCommand.ExecuteNonQuery();
                MessageBox.Show("Delete " + n.ToString() + "movie successfuly.", "Remove Movie", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mySqlConnection.Close();
                txtName.Text = "";
            }
            catch (Exception err){
                MessageBox.Show(err.Message, "Remove Movie", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}

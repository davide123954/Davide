﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Stav_cinema
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }
        private string GetDitails(string strSQL, int num, string namecolumn)
        {
            try
            {
                SqlConnection mySqlConnection = new SqlConnection("server=(local)\\SQLEXPRESS;database=Cinima;Integrated Security=SSPI;");//kesher to database
                SqlCommand mySqlCommand = mySqlConnection.CreateCommand();
                mySqlCommand.CommandText = strSQL;
                mySqlConnection.Open();
                SqlDataReader mySqlDataReader = mySqlCommand.ExecuteReader();
                string strPicture;
                string str = namecolumn + " \n";
                while (mySqlDataReader.Read())
                {
                    if (num != 9)
                        str += mySqlDataReader[num].ToString() + "\n";
                    else
                    {
                        str += string.Format("{0,-10} {1,13} {2,14} {3,10}\n", mySqlDataReader[0].ToString(), mySqlDataReader[1].ToString(), mySqlDataReader[2].ToString(), mySqlDataReader[3].ToString()) + "\n";
                        strPicture = mySqlDataReader[4].ToString();
                        pictureMovie.Image = Image.FromFile("pic/" + strPicture);
                    }
                }
                mySqlDataReader.Close();
                mySqlConnection.Close();
                return str;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "My Cienma", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
        private void btnShowMovie_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = GetDitails("select * from Admin;", 9, "Name            Date          Time           Price\n");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            Order x = new Order();
            x.ShowDialog();
        }

        private void btnGallery_Click(object sender, EventArgs e)
        {
            string str = comboBox1.Text;
            string command = "select * from Admin where movie_name='" + str + "';";
            richTextBox1.Text = GetDitails(command, 9, "Name            Date            Time         Price\n");
        }


    }
}
